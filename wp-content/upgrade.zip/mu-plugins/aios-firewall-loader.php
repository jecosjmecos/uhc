<?php
// Begin AIOWPSEC Firewall
if (file_exists('C:/OpenServer/domains/localhost/uhc/aios-bootstrap.php')) {
	include_once('C:/OpenServer/domains/localhost/uhc/aios-bootstrap.php');
}
// End AIOWPSEC Firewall
